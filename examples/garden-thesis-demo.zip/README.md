# garden-thesis-demo — the thesis engine, from a zip

The same invented content as `thesis-chapter-demo`, rearranged into the
**project-garden** layout so the archive arm of the thesis engine can be
exercised without anything private:

    src/01-introduction.md      a chapter, selected by its NN- prefix
    src/Dedication.md           front matter, read by name
    src/Acknowledgements.md
    src/references.bib          the main bibliography
    assets/figures/current/     figures, referenced from a chapter as figures/<name>

Build it:

    (cd examples/garden-thesis-demo && zip -qr ../garden-thesis-demo.zip .)
    curl -s -X POST localhost:8080/compile/archive \
      -F bundle=@examples/garden-thesis-demo.zip \
      -F profile=su-fmhs -F copy=examination

Unlike the quarto arm, this one does not preserve the archive's layout: the
pipeline reads fixed locations under `writeup/`, so the garden layout is mapped
into them. The job manifest reports where each file landed, and a file that
matches no mapped location is listed under `archive.ignored` rather than being
placed somewhere nothing reads.

Front matter attaches to the chapter carrying the abstracts, so a build of a
single non-introduction chapter legitimately shows the template's placeholder
pages. That is the pipeline's gating, not a mapping failure.
